#ifndef AWS_S3_META_REQUEST_IMPL_H
#define AWS_S3_META_REQUEST_IMPL_H

/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/auth/signing.h>
#include <aws/common/atomics.h>
#include <aws/common/linked_list.h>
#include <aws/common/mutex.h>
#include <aws/common/ref_count.h>
#include <aws/common/task_scheduler.h>
#include <aws/http/request_response.h>

#include "aws/s3/private/s3_checksums.h"
#include "aws/s3/private/s3_client_impl.h"
#include "aws/s3/private/s3_request.h"

struct aws_s3_client;
struct aws_s3_connection;
struct aws_s3_meta_request;
struct aws_s3_request;
struct aws_http_headers;
struct aws_http_make_request_options;
struct aws_retry_strategy;
struct aws_s3_upload_request_checksum_context;
enum aws_s3_meta_request_state {
    AWS_S3_META_REQUEST_STATE_ACTIVE,
    AWS_S3_META_REQUEST_STATE_FINISHED,
};

enum aws_s3_meta_request_update_flags {
    /* The client potentially has multiple meta requests that it can spread across connections, and the given meta
       request can selectively not return a request if there is a performance reason to do so.*/
    AWS_S3_META_REQUEST_UPDATE_FLAG_CONSERVATIVE = 0x00000002,
};

typedef void(aws_s3_meta_request_prepare_request_callback_fn)(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    int error_code,
    void *user_data);

struct aws_s3_prepare_request_payload {
    struct aws_allocator *allocator;
    struct aws_s3_request *request;
    struct aws_task task;
    /* async step: wait for vtable->prepare_request() call to complete */
    struct aws_future_void *asyncstep_prepare_request;
    /* callback to invoke when all request preparation work is complete */
    aws_s3_meta_request_prepare_request_callback_fn *callback;
    void *user_data;
};

/* One part's contribution to the meta request's whole-object checksum. Lives in
 * aws_s3_meta_request.combine_slots at index (part_number - 1).
 *
 * Deliberately plain data: it owns nothing and points at nothing, so its lifetime is the meta
 * request's and is independent of the request. That is what lets a request tear down its own running
 * checksums at stream completion while its contribution to the whole-object checksum outlives it. */
struct aws_s3_combine_slot {
    /* Length in bytes of the part body the digest covers. */
    uint64_t length;
    /* Raw (not base64) digest of the part body, `digest_len` bytes. */
    uint8_t digest[AWS_S3_COMBINABLE_DIGEST_MAX_LEN];
    /* Zero until this part records its digest. A slot still zero when the meta request finishes means
     * the part never completed, so the whole-object checksum cannot be assembled. */
    size_t digest_len;
};

/* Wrapper of a file descriptors */
struct aws_s3_recv_file_fds {
    /* The owner's descriptor. AWS_FILE_INVALID_FD until opened. */
    int fd;

    /* Whether `fd` is an O_DIRECT descriptor, which decides both how a body is written through it and
     * how it is closed. */
    bool direct;

    /* Set once the open has been attempted, so a failure is not retried per body. */
    bool open_attempted;
};

/* Bookkeeping for one part that reached its sink ahead of an earlier part, parked in
 * `synced_data.completed_deliveries_tracker` until the gap before it closes. Carries no payload and
 * nothing reads it back out except the contiguous-length accounting the download resume token reports.
 *
 * `range_start`/`range_end` is the object range the part was ASKED for, which is what lets the prefix
 * check that each part it folds in begins exactly where the previous one ended. `bytes` is what the
 * sink actually accepted, and can fall short of that range: a server may answer a part with a body
 * shorter than the Content-Range it claims, and the download steps over the shortfall rather than
 * stalling on a gap that will never close. So the two serve different purposes and neither is derivable
 * from the other -- coverage is checked from the range, delivered volume is summed from `bytes`. */
struct aws_s3_delivery_tracking_record {
    uint32_t part_number;
    uint64_t range_start;
    uint64_t range_end; /* inclusive */
    uint64_t bytes;
};

/* An event to be delivered on the meta-request's io_event_loop thread. */
struct aws_s3_meta_request_event {
    enum aws_s3_meta_request_event_type {
        AWS_S3_META_REQUEST_EVENT_RESPONSE_BODY, /* body_callback */
        AWS_S3_META_REQUEST_EVENT_PROGRESS,      /* progress_callback */
        AWS_S3_META_REQUEST_EVENT_TELEMETRY,     /* telemetry_callback */
    } type;

    union {
        /* data for AWS_S3_META_REQUEST_EVENT_RESPONSE_BODY */
        struct {
            struct aws_s3_request *completed_request;
            size_t bytes_delivered;
        } response_body;

        /* data for AWS_S3_META_REQUEST_EVENT_PROGRESS */
        struct {
            struct aws_s3_meta_request_progress info;
        } progress;

        /* data for AWS_S3_META_REQUEST_EVENT_TELEMETRY */
        struct {
            struct aws_s3_request_metrics *metrics;
        } telemetry;
    } u;
};

struct aws_s3_meta_request_vtable {
    /* Update the meta request.  out_request is required to be non-null. Returns true if there is any work in
     * progress, false if there is not. */
    bool (*update)(struct aws_s3_meta_request *meta_request, uint32_t flags, struct aws_s3_request **out_request);

    /* Run vtable->prepare_request() on the meta-request's event loop.
     * We do this because body streaming is slow, and we don't want it on our networking threads.
     * The callback may fire on any thread (an async sub-step may run on another thread). */
    void (*schedule_prepare_request)(
        struct aws_s3_meta_request *meta_request,
        struct aws_s3_request *request,
        aws_s3_meta_request_prepare_request_callback_fn *callback,
        void *user_data);

    /* Given a request, asynchronously prepare it for sending
     * (creating the correct HTTP message, reading from a stream (if necessary), computing hashes, etc.).
     * Returns a future, which may complete on any thread (and may complete synchronously). */
    struct aws_future_void *(*prepare_request)(struct aws_s3_request *request);

    void (*init_signing_date_time)(struct aws_s3_meta_request *meta_request, struct aws_date_time *date_time);

    /* Sign the given request. */
    void (*sign_request)(
        struct aws_s3_meta_request *meta_request,
        struct aws_s3_request *request,
        aws_signing_complete_fn *on_signing_complete,
        void *user_data);

    /* Called when any sending of the request is finished, including for each retry. */
    void (*send_request_finish)(struct aws_s3_connection *connection, struct aws_http_stream *stream, int error_code);

    /* Called when the request is done being sent, and will not be retried/sent again. */
    void (*finished_request)(struct aws_s3_meta_request *meta_request, struct aws_s3_request *request, int error_code);

    /* Called by the derived meta request when the meta request is completely finished. */
    void (*finish)(struct aws_s3_meta_request *meta_request);

    /* Handle de-allocation of the meta request. */
    void (*destroy)(struct aws_s3_meta_request *);

    /* Pause the given request */
    int (*pause)(struct aws_s3_meta_request *meta_request, struct aws_s3_meta_request_resume_token **resume_token);

    /* Optional. Build a resume token from current synced state; called with the synced-data lock held
     * when a pause was requested (or an error occurred and on_error_resume_token is set).
     * May return NULL to indicate no resumable state (caller must restart from the beginning). */
    struct aws_s3_meta_request_resume_token *(*build_resume_token_synced)(struct aws_s3_meta_request *meta_request);

#ifdef AWS_C_S3_ENABLE_TEST_STUBS
    /********************* TEST ONLY STUB **************************/
    /* A stub to the update implementation from meta request with the lock held. Only for tests. */
    bool (*synced_update_stub)(struct aws_s3_meta_request *meta_request);

    /* Stands in for the positional write to the receive file when set, so a test can make a write fail
     * without arranging a real I/O error. Return AWS_OP_SUCCESS to stand in for a completed write, or
     * aws_raise_error(...) and AWS_OP_ERR to fail one. Sits ahead of the descriptor open, so a stub
     * that never returns success means no descriptor is ever opened.
     *
     * Covers both write paths, since they funnel through the same function: a parallel worker writing
     * out of order, and the ordered delivery thread. Only for tests. */
    int (*recv_file_write_stub)(
        struct aws_s3_meta_request *meta_request,
        uint64_t file_offset,
        const struct aws_byte_cursor *body);
#endif
};

/**
 * This represents one meta request, ie, one accelerated file transfer.  One S3 meta request can represent multiple S3
 * requests.
 */
struct aws_s3_meta_request {
    struct aws_allocator *allocator;

    struct aws_ref_count ref_count;

    void *impl;

    struct aws_s3_meta_request_vtable *vtable;

    /* Initial HTTP Message that this meta request is based on. */
    struct aws_http_message *initial_request_message;

    /* The meta request's outgoing body comes from one of these:
     * 1) request_body_async_stream: if set, then async stream 1 part at a time
     * 2) request_body_parallel_stream: if set, then stream multiple parts in parallel
     * 3) request_body_using_async_writes: if set, then synchronously copy async_write data from 1 part at a time
     * 4) initial_request_message's body_stream: else synchronously stream parts */
    struct aws_async_input_stream *request_body_async_stream;
    struct aws_parallel_input_stream *request_body_parallel_stream;
    bool request_body_using_async_writes;

    /* Part size to use for uploads and downloads.  Passed down by the creating client. */
    const size_t part_size;
    /* Hard limit on max connections set through the meta request option. */
    const uint32_t max_active_connections_override;

    struct aws_cached_signing_config_aws *cached_signing_config;

    /* Client that created this meta request which also processes this request. After the meta request is finished, this
     * reference is removed.*/
    struct aws_s3_client *client;

    struct aws_s3_endpoint *endpoint;

    /* Number of requests being sent/received over network for the meta request. */
    struct aws_atomic_var num_requests_network;

    /* Event loop to schedule IO work related on, ie, reading from streams, streaming parts back to the caller, etc...
     * After the meta request is finished, this will be reset along with the client reference.*/
    struct aws_event_loop *io_event_loop;

    /* User data to be passed to each customer specified callback.*/
    void *user_data;

    /* Customer specified callbacks. */
    aws_s3_meta_request_headers_callback_fn *headers_callback;
    aws_s3_meta_request_receive_body_callback_fn *body_callback;
    aws_s3_meta_request_receive_body_callback_ex_fn *body_callback_ex;
    aws_s3_meta_request_finish_fn *finish_callback;

    aws_s3_meta_request_pause_complete_fn *on_error_resume_token;
    aws_s3_meta_request_shutdown_fn *shutdown_callback;
    aws_s3_meta_request_progress_fn *progress_callback;
    aws_s3_meta_request_telemetry_fn *telemetry_callback;
    aws_s3_meta_request_upload_review_fn *upload_review_callback;

    enum aws_s3_meta_request_type type;
    struct aws_string *s3express_session_host;
    /* Is the meta request made to s3express bucket or not. */
    bool is_express;
    /* Is the meta request made over TLS (https) or plaintext (http). */
    bool is_https;
    /* If the buffer pool optimized for the specific size or not. */
    bool buffer_pool_optimized;

    /* Track the number of requests being prepared for this meta request. */
    struct aws_atomic_var num_request_being_prepared;

    struct {
        struct aws_mutex lock;

        /* Priority queue for pending streaming requests.  We use a priority queue to keep parts in order so that we
         * can stream them to the caller in order. */
        struct aws_priority_queue pending_body_streaming_requests;

        /* Current state of the meta request. */
        enum aws_s3_meta_request_state state;

        /* The sum of initial_read_window, plus all window_increment() calls. This number never goes down. */
        uint64_t read_window_running_total;

        /* The next expected streaming part number needed to continue streaming part bodies. (For example, this will
         * initially be 1 for part 1, and after that part is received, it will be 2, then 3, etc.. )*/
        uint32_t next_streaming_part;

        /* Number of parts scheduled for delivery. */
        uint32_t num_parts_delivery_sent;

        /* Total number of parts that have been attempted to be delivered. (Will equal the sum of succeeded and
         * failed.)*/
        uint32_t num_parts_delivery_completed;

        /* One bit per part, bit (N-1) for part N, least significant bit first within each byte. Set when
         * a part finishes sinking — written to the file or delivered through the body callback. Checked
         * when the meta request is about to complete: every bit must be set. Catches any path that drops
         * or duplicates a part. Allocated by the auto-ranged-get implementation once total_num_parts is
         * known; NULL for meta request types that do not split a download into parts. */
        uint8_t *parts_delivered_mask;

        /* How many bytes `parts_delivered_mask` actually points at, so every index into it is bounded by
         * what was allocated rather than by a size recomputed at each use. An eighth of
         * `parts_delivered_mask_num_parts`, rounded up; the two are cross-checked before the mask is
         * walked, so a future allocation site that sets one without the other is caught rather than
         * reading off the end. */
        uint32_t parts_delivered_mask_length;

        /* How many parts the mask covers, so it occupies an eighth of this many bytes, rounded up. Also
         * the upper bound a part number is range-checked against before its bit is touched. */
        uint32_t parts_delivered_mask_num_parts;

        /* Bytes delivered contiguously from the start of the range, with no gaps. This is what the
         * download resume token reports as `continuous_downloaded_bytes`, so it may only count a part
         * once every earlier part has also landed. `next_contiguous_delivered_part` and
         * `completed_deliveries_tracker` track that for out-of-order delivery. */
        uint64_t num_bytes_delivered;

        /* Every byte delivered, including parts that landed past a gap. Reported as the token's
         * `total_downloaded_bytes`. Equal to `num_bytes_delivered` when delivery was in order. */
        uint64_t num_bytes_delivered_total;

        /* Next part number that would extend the contiguous delivered prefix. */
        uint32_t next_contiguous_delivered_part;

        /* Object range start the next contiguous part must begin at, which is where the previous part's
         * range ended. Seeded from part 1's own range start, since for a ranged download the prefix
         * begins at the range rather than at 0. */
        uint64_t next_contiguous_delivered_range_start;

        /* Min-heap by part number of parts that reached their sink ahead of an earlier part, holding
         * `struct aws_s3_delivery_tracking_record`. Drained into `num_bytes_delivered` as the gap closes. */
        struct aws_priority_queue completed_deliveries_tracker;

        /* Task for delivering events on the meta-request's io_event_loop thread.
         * We do this to ensure a meta-request's callbacks are fired sequentially and non-overlapping.
         * If `event_delivery_task_scheduled` is true, then this task is scheduled.
         * If `event_delivery_active` is true, then this task is actively running.
         * Delivery is not 100% complete until `event_delivery_array` is empty AND `event_delivery_active` is false
         * (use aws_s3_meta_request_are_events_out_for_delivery_synced()  to check) */
        struct aws_task event_delivery_task;

        /* Whether or not event delivery is currently scheduled. */
        uint32_t event_delivery_task_scheduled : 1;

        /* Array of `struct aws_s3_meta_request_event` to deliver when the `event_delivery_task` runs. */
        struct aws_array_list event_delivery_array;

        /* When true, events are actively being delivered to the user. */
        bool event_delivery_active;

        /* The end finish result of the meta request. */
        struct aws_s3_meta_request_result finish_result;

        /* True if the finish result has been set. */
        uint32_t finish_result_set : 1;

        /* Pause state (see aws_s3_meta_request_pause_async). Set once when a pause is requested;
         * consumed during finish to build a resume token and fire the pause callback. */
        uint32_t async_pause_requested : 1;
        aws_s3_meta_request_pause_complete_fn *pause_complete_callback;
        void *pause_complete_user_data;

        /* To track aws_s3_requests with cancellable HTTP streams */
        struct aws_linked_list cancellable_http_streams_list;

        /* To track aws_future_s3_buffers that might need to be cleaned up on cancel */
        struct aws_linked_list pending_buffer_futures;

        /* Data for async-writes. */
        struct aws_s3_async_write_data {
            /* Whether a part request can be sent (we have 1 part's worth of data, or EOF) */
            bool ready_to_send;

            /* True once user passes `eof` to their final write() call */
            bool eof;

            /* Holds buffered data we can't immediately send.
             * The length will always be less than part-size */
            struct aws_byte_buf buffered_data;
            struct aws_s3_buffer_ticket *buffered_data_ticket;

            /* Set while we're waiting on the buffer pool to fulfill a (deferred) ticket reservation
             * for buffered_data_ticket. While set, poll_write() returns result.is_pending. */
            struct aws_future_s3_buffer_ticket *buffered_data_ticket_future;

            /* Waker callback.
             * Stored if a poll_write() call returns result.is_pending
             * (because we already had 1 part's worth of data, or because we're
             * waiting on the buffer pool to fulfill a ticket reservation).
             * Invoked when we're ready to accept another poll_write() call. */
            aws_simple_completion_callback *waker;
            void *waker_user_data;
        } async_write;

    } synced_data;

    /* Anything in this structure should only ever be accessed by the client on its process work event loop task. */
    struct {

        /* Linked list node for the meta requests linked list in the client. */
        /* Note: this needs to be first for using AWS_CONTAINER_OF with the nested structure. */
        struct aws_linked_list_node node;

        /* True if this meta request is currently in the client's list. */
        bool scheduled;

    } client_process_work_threaded_data;

    /* Anything in this structure should only ever be accessed by the meta-request from its io_event_loop thread. */
    struct {
        /* When delivering events, we swap contents with `synced_data.event_delivery_array`.
         * This is an optimization, we could have just copied the array when the task runs,
         * but swapping two array-lists back and forth avoids an allocation. */
        struct aws_array_list event_delivery_array;

        /* The range start for the next response body delivery */
        uint64_t next_deliver_range_start;

        /* Total number of bytes that have been attempted to be delivered. (Will equal the sum of succeeded and
         * failed.)*/
        uint64_t num_bytes_delivery_completed;

        /* Priority queue of requests that have acquired their buffer ticket but must wait
         * for earlier parts to be dispatched for prepare first. This ensures sequential
         * input stream reads happen in part-number order even when buffer pool reservations
         * complete out of order.
         * Note: each element is the pending request, callback to the next state and some user data
         * (aws_s3_pending_prepare_entry). */
        struct aws_priority_queue pending_put_prepare_queue;

        /* Next part number that should be dispatched from pending_put_prepare_queue. */
        uint32_t next_put_part_to_prepare;

        /* Expected offset for the next sequential stream read. Used to detect out-of-order reads. */
        uint64_t next_read_offset;
    } io_threaded_data;

    const bool should_compute_content_md5;

    /* deep copy of the checksum config. */
    struct aws_s3_meta_request_checksum_config_storage checksum_config;

    /* checksum found in either a default get request, or in the initial head request of a multipart get */
    struct aws_byte_buf meta_request_level_response_header_checksum;

    /* running checksum of all the parts of a default get, or ranged get meta request*/
    struct aws_s3_checksum *meta_request_level_running_response_sum;

    /* True when meta_request_level_running_response_sum uses an algorithm that aws_checksum_combine supports
     * (the CRCs). In that case each part computes a digest of its own body on its connection's thread and
     * records it in combine_slots, and the whole-object sum is assembled from those digests with an O(1)
     * combine per part when the meta request finishes, so no thread re-reads the body. Otherwise the delivery
     * thread feeds bytes into the running sum directly, which requires delivery to be in object order. */
    bool meta_request_level_checksum_combinable;

    /* Per-part digests will be folded into meta_request_level_running_response_sum, indexed by
     * (part_number - 1). NULL unless meta_request_level_checksum_combinable is true.
     *
     * Not protected by the synced data lock, and does not need to be: the array is allocated once, before any
     * part is dispatched, and never resized, so slot addresses are stable; each part writes only its own slot
     * and touches no shared bookkeeping. */
    struct aws_s3_combine_slot *combine_slots;
    /* Number of entries in combine_slots. Zero when combine_slots is NULL. */
    uint32_t combine_slot_count;

    /* Bitmask of enum aws_s3_feature_id emitted in the User-Agent m/ section for every request
     * belonging to this meta request. Client-level flags OR'd with per-request flags derived from
     * aws_s3_meta_request_options at creation time. Immutable after init. */
    uint32_t feature_ids;

    /* Optional caller-provided in-memory download destination (zero-copy).
     * Non-NULL means each part is written directly into this buffer at
     * (part range start - requested_range_start); the client neither allocates nor frees it.
     * Set only once it has been added to the client's buffer pool, so destroy removes it then.
     * See aws_s3_meta_request_options.recv_buffer. */
    struct aws_byte_buf *recv_buffer;
    /* Number of bytes the download will write into recv_buffer (the discovered range length; 0 for an
     * empty object). Copied into recv_buffer->len when the meta request succeeds. */
    uint64_t recv_buffer_expected_len;
    /* Pre-built User-Agent header value, computed once at init from the SDK's existing header +
     * CRT product token + merged m/ section (SDK IDs + operation-level CRT IDs). Per-part
     * stamping copies this and may append per-part-only feature IDs. */
    struct aws_byte_buf cached_user_agent;
    bool cached_ua_has_metrics; /* true if cached_user_agent already contains an m/ section */

    /* True when this is the first meta-request on a newly created client. Consumed (set to false)
     * on the first HTTP request so CLIENT_CREATED_FOR_OP (Al) appears exactly once. */
    bool first_request_for_new_client;

    /* Destination path for a download. The file itself is created or truncated once at init through a
     * short-lived stdio handle; received bytes are written only through the descriptors in
     * `recv_file_write_fd_slots` and `recv_file_ordered_fds`. */
    struct aws_string *recv_filepath;
    bool recv_file_delete_on_failure;
    /* Set by the finish call once it has kept (success, pause) or deleted (failure) the receive file. Destroy
     * deletes on failure only while this is false, which means creation failed after the file was opened. */
    bool recv_file_finalized;
    /* When true, attempt O_DIRECT for writes. Only read when a writer opens its descriptor. */
    bool recv_file_direct_io;

    /* This request's override of the client's `out_of_order_delivery`, from the creation options.
     * AWS_TRIBOOL_UNSET means defer to the client. Immutable after init. */
    enum aws_tribool out_of_order_delivery_override;

    /* Whether bodies reach their sink out of object order: to a file through the descriptor of whichever
     * worker takes the part, or to the body callback without waiting on the part ahead of it. Nonzero
     * for yes.
     *
     * Written once, by the auto-ranged GET implementation as it finishes discovery. That is the earliest
     * point the answer is knowable -- a whole-object checksum's ordering demand arrives with the discovery
     * response's headers -- and the last point at which no part but discovery's own exists, so nothing has
     * been delivered under one answer and then finds another. Read-only from then on.
     *
     * Stays false under every other implementation. Out-of-order delivery is a statement about the order of
     * a download's parts, and an implementation that does not split a download into parts has no such
     * order. Note that this is about the implementation and not `type`: a GET whose query already names a
     * partNumber carries type GET_OBJECT but runs as a default meta request, and so leaves this false.
     *
     * Atomic because a retried discovery resolves this while the event delivery task may be draining a
     * telemetry or progress event from the attempt that failed. */
    struct aws_atomic_var out_of_order_delivery;

    /* One descriptor pair per write worker, indexed by the worker's file_io_elg loop index.
     * Length is recv_file_write_fd_slot_count.
     *
     * Giving each worker its own pair keeps every write single-writer: two workers never share a
     * struct file, so they never contend on its reference count, and a slot needs no lock because
     * only its own worker thread ever touches it.
     *
     * Opened lazily by the owning worker, since a meta request that only ever lands on a few workers
     * should not pay for descriptors it never uses.
     *
     * No lock: the array is allocated before any part is dispatched and never resized, and each
     * element is owned exclusively by one worker thread. Same argument as combine_slots. */
    struct aws_s3_recv_file_fds *recv_file_write_fd_slots;
    size_t recv_file_write_fd_slot_count;

    /* Descriptor for the ordered delivery path, which has no worker slot of its own. Owned by the meta
     * request's io_event_loop thread, the only thread that writes when `out_of_order_delivery` is false,
     * so it is never shared with a worker. */
    struct aws_s3_recv_file_fds recv_file_ordered_fds;

    /* Base file offset for writes. 0 for CREATE_*, `recv_file_position` for WRITE_TO_POSITION,
     * existing file size for CREATE_OR_APPEND. */
    uint64_t recv_file_base_offset;

    /* The object range start that maps to the start of the download's destination: offset
     * `recv_file_base_offset` in the file, or offset 0 in `recv_buffer`. Zero for a whole-object
     * download; for a ranged one it is the range's start, because a part has its absolute position in
     * the object and the caller expects the range's first byte at the destination's start. Set by the
     * derived meta request when it resolves the object range, before any body is delivered; for
     * recv_buffer it is set at creation when already known, since a part is placed when its buffer is
     * reserved, before the first response. Zero for an upload, set at creation. Must be resolved before
     * any part reserves a pool buffer, since the reservation's local_offset is measured from it. */
    uint64_t requested_range_start;

    /* Whether requested_range_start has been resolved. */
    bool requested_range_start_resolved;

    /* Counter for how many times we fell back from O_DIRECT to buffered I/O for a single part.
     * Init-time fallbacks (non-Linux, unaligned part_size, unaligned WRITE_TO_POSITION/APPEND offset)
     * also increment this counter. The warning is only logged when this transitions from 0,
     * to avoid log spam. */
    struct aws_atomic_var recv_file_direct_io_fallback_count;

    /* File I/O options. */
    struct aws_s3_file_io_options fio_opts;
};

/* Entry in the pending_put_prepare_queue. Holds a request that has acquired its buffer
 * ticket but must wait for earlier parts to dispatch for prepare first. */
struct aws_s3_pending_prepare_entry {
    struct aws_s3_request *request;
    aws_s3_meta_request_prepare_request_callback_fn *callback;
    void *user_data;
};

/* Info for each part, that we need to remember until we send CompleteMultipartUpload */
struct aws_s3_mpu_part_info {
    uint64_t size;
    struct aws_string *etag;
    struct aws_s3_upload_request_checksum_context *checksum_context;
    bool was_previously_uploaded;
};

AWS_EXTERN_C_BEGIN

/* Initialize the base meta request structure. */
AWS_S3_API
int aws_s3_meta_request_init_base(
    struct aws_allocator *allocator,
    struct aws_s3_client *client,
    size_t part_size,
    bool should_compute_content_md5,
    bool should_default_streaming,
    const struct aws_s3_meta_request_options *options,
    void *impl,
    struct aws_s3_meta_request_vtable *vtable,
    struct aws_s3_meta_request *base_type);

/* Returns true if the meta request is still in the "active" state. */
AWS_S3_API
bool aws_s3_meta_request_is_active(struct aws_s3_meta_request *meta_request);

/* Returns true if the meta request is in the "finished" state. */
AWS_S3_API
bool aws_s3_meta_request_is_finished(struct aws_s3_meta_request *meta_request);

/* Returns true if the meta request has a finish result, which indicates that the meta request has trying to finish or
 * has already finished. */
AWS_S3_API
bool aws_s3_meta_request_has_finish_result(struct aws_s3_meta_request *meta_request);

AWS_S3_API
void aws_s3_meta_request_lock_synced_data(struct aws_s3_meta_request *meta_request);

AWS_S3_API
void aws_s3_meta_request_unlock_synced_data(struct aws_s3_meta_request *meta_request);

/* Called by the client to retrieve the next request and update the meta request's internal state. out_request is
 * optional, and can be NULL if just desiring to update internal state. */
AWS_S3_API
bool aws_s3_meta_request_update(
    struct aws_s3_meta_request *meta_request,
    uint32_t flags,
    struct aws_s3_request **out_request);

AWS_S3_API
void aws_s3_meta_request_prepare_request(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_s3_meta_request_prepare_request_callback_fn *callback,
    void *user_data);

AWS_S3_API
void aws_s3_meta_request_send_request(struct aws_s3_meta_request *meta_request, struct aws_s3_connection *connection);

AWS_S3_API
void aws_s3_meta_request_init_signing_date_time_default(
    struct aws_s3_meta_request *meta_request,
    struct aws_date_time *date_time);

AWS_S3_API
void aws_s3_meta_request_sign_request_default_impl(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_signing_complete_fn *on_signing_complete,
    void *user_data,
    bool disable_s3_express_signing);

AWS_S3_API
void aws_s3_meta_request_sign_request_default(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_signing_complete_fn *on_signing_complete,
    void *user_data);

/* Default implementation for when a request finishes a particular send. */
AWS_S3_API
void aws_s3_meta_request_send_request_finish_default(
    struct aws_s3_connection *connection,
    struct aws_http_stream *stream,
    int error_code);

/* Called by the client when a request is completely finished and not doing any further retries. */
AWS_S3_API
void aws_s3_meta_request_finished_request(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    int error_code);

/* Called to place the request in the meta request's priority queue for streaming back to the caller.  Once all requests
 * with a part number less than the given request has been received, the given request and the previous requests will
 * be scheduled for streaming.  */
AWS_S3_API
void aws_s3_meta_request_stream_response_body_synced(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request);

/* Decides how the whole-object response checksum will be built, once the discovery response has told us which
 * algorithm the object uses and how many parts it has. Call after aws_s3_check_headers_for_checksum() has run
 * at the meta request level, before any part is dispatched, with the meta request's synced data lock HELD.
 *
 * For the CRCs, each part checksums its own body on its own connection's thread and records the digest in
 * meta_request->combine_slots, which this function allocates. The digests are folded together with an O(1)
 * combine per part when the meta request finishes, so no thread ever re-reads the object. Everything else
 * falls back to feeding the running sum from the delivery thread.
 *
 * `discovery_request` is the request whose response headers were just inspected. If it carried body bytes of
 * its own (a partNumber=1 GET rather than a HEAD), its digest is computed here, since its body may arrive before
 * the algorithm was known.
 *
 * Only worth calling for multipart downloads; with a single request there are no parts to combine. */
AWS_S3_API
int aws_s3_meta_request_setup_checksum_combine_synced(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *discovery_request,
    uint32_t total_num_parts);

/* Add an event for delivery on the meta-request's io_event_loop thread.
 * These events usually correspond to callbacks that must fire sequentially and non-overlapping,
 * such as delivery of a part's response body. */
void aws_s3_meta_request_add_event_for_delivery_synced(
    struct aws_s3_meta_request *meta_request,
    const struct aws_s3_meta_request_event *event);

/* Returns whether any events are out for delivery.
 * The meta-request's finish callback must not be invoked until this returns false. */
bool aws_s3_meta_request_are_events_out_for_delivery_synced(struct aws_s3_meta_request *meta_request);

/* Cancel the requests with cancellable HTTP stream for the meta request */
AWS_S3_API
void aws_s3_meta_request_cancel_cancellable_requests_synced(struct aws_s3_meta_request *meta_request, int error_code);

/* Cancel the pending buffer futures for the meta request */
AWS_S3_API
void aws_s3_meta_request_cancel_pending_buffer_futures_synced(struct aws_s3_meta_request *meta_request, int error_code);

/* Asynchronously read from the meta request's input stream. Should always be done outside of any mutex,
 * as reading from the stream could cause user code to call back into aws-c-s3.
 * This will fill the buffer to capacity, unless end of stream is reached.
 * It may read from the underlying stream multiple times, if that's what it takes to fill the buffer.
 * Returns a future whose result bool indicates whether end of stream was reached.
 * This future may complete on any thread, and may complete synchronously.
 *
 * Read from offset to fill the buffer
 */
AWS_S3_API
struct aws_future_bool *aws_s3_meta_request_read_body(
    struct aws_s3_meta_request *meta_request,
    uint64_t offset,
    struct aws_byte_buf *buffer);

/* Set the meta request finish result as failed. This is meant to be called sometime before aws_s3_meta_request_finish.
 * Subsequent calls to this function or to aws_s3_meta_request_set_success_synced will not overwrite the end result of
 * the meta request. */
AWS_S3_API
void aws_s3_meta_request_set_fail_synced(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *failed_request,
    int error_code);

/* Set the meta request finish result as successful. This is meant to be called sometime before
 * aws_s3_meta_request_finish. Subsequent calls this function or to aws_s3_meta_request_set_fail_synced will not
 * overwrite the end result of the meta request. */
AWS_S3_API
void aws_s3_meta_request_set_success_synced(struct aws_s3_meta_request *meta_request, int response_status);

/* Check that every part in `parts_delivered_mask` was marked, the last chance to catch a part that was
 * never delivered before the meta request reports success. Raises AWS_ERROR_INVALID_STATE naming the first
 * missing part when one is absent, so the caller can fail the meta request instead of claiming a complete
 * download. Returns AWS_OP_SUCCESS when the mask is full, and when there is no mask at all -- meta request
 * types that do not split a download into parts never allocate one. Leaves the mask in place; the caller
 * owns releasing it. */
AWS_S3_API
int aws_s3_meta_request_validate_parts_delivered_synced(struct aws_s3_meta_request *meta_request);

/* Returns true if the finish result has been set (ie: either aws_s3_meta_request_set_fail_synced or
 * aws_s3_meta_request_set_success_synced have been called.) */
AWS_S3_API
bool aws_s3_meta_request_has_finish_result_synced(struct aws_s3_meta_request *meta_request);

/* Virtual function called by the meta request derived type when it's completely finished and there is no other work to
 * be done. */
AWS_S3_API
void aws_s3_meta_request_finish(struct aws_s3_meta_request *meta_request);

/* Default implementation of the meta request finish function. */
AWS_S3_API
void aws_s3_meta_request_finish_default(struct aws_s3_meta_request *meta_request);

/* Sets up a meta request result structure. */
AWS_S3_API
void aws_s3_meta_request_result_setup(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_meta_request_result *result,
    struct aws_s3_request *failed_request,
    int response_status,
    int error_code);

/* Cleans up a meta request result structure. */
AWS_S3_API
void aws_s3_meta_request_result_clean_up(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_meta_request_result *result);

AWS_S3_API
bool aws_s3_meta_request_checksum_config_has_algorithm(
    struct aws_s3_meta_request *meta_request,
    enum aws_s3_checksum_algorithm algorithm);

void aws_s3_meta_request_schedule_prepare_request_default_impl(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    bool parallel,
    aws_s3_meta_request_prepare_request_callback_fn *callback,
    void *user_data);

AWS_EXTERN_C_END

#endif /* AWS_S3_META_REQUEST_IMPL_H */
