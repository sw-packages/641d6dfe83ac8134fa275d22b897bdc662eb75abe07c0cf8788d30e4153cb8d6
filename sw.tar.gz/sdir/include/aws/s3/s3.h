#ifndef AWS_S3_H
#define AWS_S3_H

/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/common/common.h>
#include <aws/io/logging.h>
#include <aws/s3/exports.h>

AWS_PUSH_SANE_WARNING_LEVEL

#define AWS_C_S3_PACKAGE_ID 14

enum aws_s3_errors {
    AWS_ERROR_S3_MISSING_CONTENT_RANGE_HEADER = AWS_ERROR_ENUM_BEGIN_RANGE(AWS_C_S3_PACKAGE_ID),
    AWS_ERROR_S3_INVALID_CONTENT_RANGE_HEADER,
    AWS_ERROR_S3_MISSING_CONTENT_LENGTH_HEADER,
    AWS_ERROR_S3_INVALID_CONTENT_LENGTH_HEADER,
    AWS_ERROR_S3_MISSING_ETAG,
    AWS_ERROR_S3_INTERNAL_ERROR,
    AWS_ERROR_S3_SLOW_DOWN,
    AWS_ERROR_S3_INVALID_RESPONSE_STATUS,
    AWS_ERROR_S3_MISSING_UPLOAD_ID,
    AWS_ERROR_S3_PROXY_PARSE_FAILED,
    AWS_ERROR_S3_UNSUPPORTED_PROXY_SCHEME,
    AWS_ERROR_S3_CANCELED,
    AWS_ERROR_S3_INVALID_RANGE_HEADER,
    AWS_ERROR_S3_MULTIRANGE_HEADER_UNSUPPORTED,
    AWS_ERROR_S3_RESPONSE_CHECKSUM_MISMATCH,
    AWS_ERROR_S3_CHECKSUM_CALCULATION_FAILED,
    AWS_ERROR_S3_PAUSED,
    AWS_ERROR_S3_LIST_PARTS_PARSE_FAILED,
    AWS_ERROR_S3_RESUMED_PART_CHECKSUM_MISMATCH,
    AWS_ERROR_S3_RESUME_FAILED,
    AWS_ERROR_S3_OBJECT_MODIFIED,
    AWS_ERROR_S3_NON_RECOVERABLE_ASYNC_ERROR,
    AWS_ERROR_S3_METRIC_DATA_NOT_AVAILABLE,
    AWS_ERROR_S3_INCORRECT_CONTENT_LENGTH,
    AWS_ERROR_S3_REQUEST_TIME_TOO_SKEWED,
    AWS_ERROR_S3_FILE_MODIFIED,
    AWS_ERROR_S3_EXCEEDS_MEMORY_LIMIT,
    AWS_ERROR_S3_INVALID_MEMORY_LIMIT_CONFIG,
    AWS_ERROR_S3EXPRESS_CREATE_SESSION_FAILED,
    AWS_ERROR_S3_INTERNAL_BUFFER_SIZE_MISMATCH_RETRYING_WITH_RANGE,
    AWS_ERROR_S3_REQUEST_HAS_COMPLETED,
    AWS_ERROR_S3_RECV_FILE_ALREADY_EXISTS,
    AWS_ERROR_S3_RECV_FILE_NOT_FOUND,
    AWS_ERROR_S3_REQUEST_TIMEOUT,
    AWS_ERROR_S3_BUFFER_ALLOCATION_FAILED,
    AWS_ERROR_S3_PART_SIZE_EXCEEDS_MEMORY_LIMIT,

    /* Dont insert anything past this line.
        Everything below is non-nefarious hacks to preserve backwards compat */
    AWS_ERROR_S3_INTERNAL_PART_SIZE_MISMATCH_RETRYING_WITH_RANGE =
        AWS_ERROR_S3_INTERNAL_BUFFER_SIZE_MISMATCH_RETRYING_WITH_RANGE,

    AWS_ERROR_S3_END_RANGE = AWS_ERROR_ENUM_END_RANGE(AWS_C_S3_PACKAGE_ID)
};

enum aws_s3_subject {
    AWS_LS_S3_GENERAL = AWS_LOG_SUBJECT_BEGIN_RANGE(AWS_C_S3_PACKAGE_ID),
    AWS_LS_S3_CLIENT,
    AWS_LS_S3_CLIENT_STATS,
    AWS_LS_S3_REQUEST,
    AWS_LS_S3_META_REQUEST,
    AWS_LS_S3_ENDPOINT,
    AWS_LS_S3_LAST = AWS_LOG_SUBJECT_END_RANGE(AWS_C_S3_PACKAGE_ID)
};

struct aws_s3_platform_info;

#ifdef _MSC_VER
#    pragma warning(push)
#    pragma warning(disable : 4626) /* assignment operator was implicitly defined as deleted */
#    pragma warning(disable : 5027) /* move assignment operator was implicitly defined as deleted */
#endif

struct aws_s3_platform_info {
    /* name of the instance-type: example c5n.18xlarge */
    struct aws_byte_cursor instance_type;
    /* max throughput for this instance type, in gigabits per second */
    double max_throughput_gbps;
    /* Whether this library recommends automatically applying its optimized
     * configuration for this instance type without explicit user opt-in. */
    bool has_recommended_configuration;
};

#ifdef _MSC_VER
#    pragma warning(pop)
#endif

AWS_EXTERN_C_BEGIN

/**
 * Initializes internal datastructures used by aws-c-s3.
 * Must be called before using any functionality in aws-c-s3.
 */
AWS_S3_API
void aws_s3_library_init(struct aws_allocator *allocator);

/**
 * Shuts down the internal datastructures used by aws-c-s3.
 */
AWS_S3_API
void aws_s3_library_clean_up(void);

/*
 * Returns the aws_s3_platform_info for current platform
 * NOTE: THIS API IS EXPERIMENTAL AND UNSTABLE
 */
AWS_S3_API
const struct aws_s3_platform_info *aws_s3_get_current_platform_info(void);

/*
 * Returns the ec2 instance_type for current platform if possible
 * NOTE: THIS API IS EXPERIMENTAL AND UNSTABLE
 */
AWS_S3_API
struct aws_byte_cursor aws_s3_get_current_platform_ec2_intance_type(bool cached_only);

/**
 * Returns the default memory pool size that aws-c-s3 would use for a given
 * throughput target. Matches the tier-based sizing aws_s3_client_new applies
 * when the caller does not set an explicit memory_limit_in_bytes.
 *
 * If throughput_target_gbps > 0, the tier table is applied directly.
 *
 * If throughput_target_gbps == 0, aws-c-s3 attempts to auto-detect the
 * throughput from the current EC2 environment via the per-family NIC
 * bandwidth table. If auto-detection succeeds and the detected throughput
 * is below the conservative right-sizing threshold (10 Gbps), the tier
 * table is applied to the detected value. Otherwise the 2 GiB default is
 * returned.
 *
 * Bindings can call this to size a language-side memory pool (e.g. a Java
 * DirectByteBuffer pool) to match the native default without duplicating
 * the tier table or the auto-detection logic.
 */
AWS_S3_API
size_t aws_s3_default_memory_limit_for_throughput(double throughput_target_gbps);

/*
 * Returns the part size, in bytes, that the client resolves to when
 * aws_s3_client_config.part_size is left at 0.
 */
AWS_S3_API
uint64_t aws_s3_default_part_size(void);

/*
 * Returns the largest part size, in bytes, the client allows for a given
 * resolved memory limit.
 *
 * A caller that sets aws_s3_client_config.max_part_size explicitly overrides
 * this, so this reports the default rather than the effective limit.
 */
AWS_S3_API
uint64_t aws_s3_default_max_part_size_for_memory_limit(uint64_t memory_limit);

/*
 * Resolves the memory limit the client takes from configuration, in the same
 * order aws_s3_client_new applies: configured_limit when non-zero, otherwise
 * the AWS_CRT_S3_MEMORY_LIMIT_IN_MB environment variable, otherwise
 * AWS_CRT_S3_MEMORY_LIMIT_IN_GIB.
 *
 * Writes 0 when none of the three is set. That is not an error: it means the
 * caller should size from aws_s3_default_memory_limit_for_throughput, which
 * is what the client does. The two are kept separate because a configured
 * limit and a derived one are not interchangeable.
 *
 * Returns AWS_OP_ERR, having raised an error, when an environment variable is
 * present but not a non-negative integer, or overflows when scaled to bytes.
 * aws_s3_client_new fails client creation in that case, so a binding that
 * resolves the limit ahead of the client should treat it the same way rather
 * than silently falling back.
 */
AWS_S3_API
int aws_s3_resolve_configured_memory_limit(
    struct aws_allocator *allocator,
    uint64_t configured_limit,
    uint64_t *out_memory_limit);

/*
 * Retrieves a list of EC2 instance types with recommended configuration.
 * Returns aws_array_list<aws_byte_cursor>. The caller is responsible for cleaning up the array list.
 */
AWS_S3_API
struct aws_array_list aws_s3_get_platforms_with_recommended_config(void);

AWS_EXTERN_C_END
AWS_POP_SANE_WARNING_LEVEL

#endif /* AWS_S3_H */
