#ifndef AWS_S3_UTIL_H
#define AWS_S3_UTIL_H

/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

/* This file provides access to useful constants and simple utility functions. */

#include <aws/auth/signing_config.h>
#include <aws/common/byte_buf.h>
#include <aws/s3/s3_client.h>

#if ASSERT_LOCK_HELD
#    define ASSERT_SYNCED_DATA_LOCK_HELD(object)                                                                       \
        {                                                                                                              \
            int cached_error = aws_last_error();                                                                       \
            AWS_ASSERT(aws_mutex_try_lock(&(object)->synced_data.lock) == AWS_OP_ERR);                                 \
            aws_raise_error(cached_error);                                                                             \
        }
#else
#    define ASSERT_SYNCED_DATA_LOCK_HELD(object)
#endif
#define KB_TO_BYTES(kb) ((kb) * 1024)
#define MB_TO_BYTES(mb) ((mb) * 1024 * 1024)
#define GB_TO_BYTES(gb) ((uint64_t)(gb) * 1024 * 1024 * 1024ULL)
#define TB_TO_BYTES(tb) ((uint64_t)(tb) * 1024 * 1024 * 1024 * 1024ULL)

#define MS_TO_NS(ms) ((uint64_t)(ms) * 1000000)
#define SEC_TO_NS(ms) ((uint64_t)(ms) * 1000000000)

struct aws_allocator;
struct aws_http_stream;
struct aws_http_headers;
struct aws_http_message;
struct aws_s3_client;
struct aws_s3_request;
struct aws_s3_meta_request;
struct aws_s3_checksum;

struct aws_cached_signing_config_aws {
    struct aws_allocator *allocator;
    struct aws_string *service;
    struct aws_string *region;
    struct aws_string *signed_body_value;

    struct aws_signing_config_aws config;
};

AWS_EXTERN_C_BEGIN

AWS_S3_API
extern const struct aws_byte_cursor g_content_md5_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_trailer_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_request_validation_mode;

AWS_S3_API
extern const struct aws_byte_cursor g_enabled;

/**
 * The checksum-algorithm header name used for CopyObject and CreateMultipartUpload
 */
AWS_S3_API
extern const struct aws_byte_cursor g_checksum_algorithm_header_name;

/**
 * The checksum-algorithm header name used for PutObject, UploadParts and PutObject*
 */
AWS_S3_API
extern const struct aws_byte_cursor g_sdk_checksum_algorithm_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_s3_client_version;

AWS_S3_API
extern const struct aws_byte_cursor g_user_agent_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_user_agent_header_product_name;

AWS_S3_API
extern const struct aws_byte_cursor g_user_agent_header_platform;

AWS_S3_API
extern const struct aws_byte_cursor g_user_agent_header_unknown;

AWS_S3_API
extern const struct aws_byte_cursor g_acl_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_host_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_content_type_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_content_encoding_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_content_encoding_header_aws_chunked;

AWS_S3_API
extern const struct aws_byte_cursor g_content_length_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_decoded_content_length_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_etag_header_name;

AWS_S3_API
extern const size_t g_s3_min_upload_part_size;

AWS_S3_API
extern const struct aws_byte_cursor g_s3_service_name;

AWS_S3_API
extern const struct aws_byte_cursor g_s3express_service_name;

AWS_S3_API
extern const struct aws_byte_cursor g_range_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_if_match_header_name;

extern const struct aws_byte_cursor g_request_id_header_name;
extern const struct aws_byte_cursor g_amz_id_2_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_content_range_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_accept_ranges_header_name;

AWS_S3_API
extern const struct aws_byte_cursor g_post_method;

AWS_S3_API
extern const struct aws_byte_cursor g_head_method;

AWS_S3_API
extern const struct aws_byte_cursor g_delete_method;

AWS_S3_API
extern const uint32_t g_s3_max_num_upload_parts;

AWS_S3_API
/* TODO: now this is hard-coded as 8MB, but maybe something else is better. */
extern const size_t g_streaming_buffer_size;

AWS_S3_API
extern const double g_default_throughput_target_gbps;

AWS_S3_API
extern const uint64_t g_streaming_object_size_threshold;

AWS_S3_API
extern const uint64_t g_default_part_size_fallback;

AWS_S3_API
extern const uint64_t g_default_max_part_size;

AWS_S3_API
extern const uint64_t g_s3_optimal_range_size_alignment;

AWS_S3_API
extern const uint32_t g_s3express_connection_limitation;
AWS_S3_API
extern const uint64_t g_s3express_connection_limitation_part_size_threshold;
AWS_S3_API
extern const uint64_t g_s3express_connection_limitation_object_size_threshold;

/**
 * Returns AWS_S3_REQUEST_TYPE_UNKNOWN if name doesn't map to an enum value.
 */
AWS_S3_API
enum aws_s3_request_type aws_s3_request_type_from_operation_name(struct aws_byte_cursor name);

/**
 * Return operation name for aws_s3_request_type as static-lifetime aws_string*
 * or NULL if the type doesn't map to an actual operation.
 * For example:
 * AWS_S3_REQUEST_TYPE_HEAD_OBJECT -> static aws_string "HeadObject"
 * AWS_S3_REQUEST_TYPE_UNKNOWN -> NULL
 * AWS_S3_REQUEST_TYPE_MAX -> NULL
 */
AWS_S3_API
struct aws_string *aws_s3_request_type_to_operation_name_static_string(enum aws_s3_request_type type);

/**
 * Cache and initial the signing config based on the client.
 *
 * @param client
 * @param signing_config
 * @return struct aws_cached_signing_config_aws*
 */
struct aws_cached_signing_config_aws *aws_cached_signing_config_new(
    struct aws_s3_client *client,
    const struct aws_signing_config_aws *signing_config);

void aws_cached_signing_config_destroy(struct aws_cached_signing_config_aws *cached_signing_config);

/* Sets all headers specified for src on dest */
AWS_S3_API
void copy_http_headers(const struct aws_http_headers *src, struct aws_http_headers *dest);

/**
 * Get content of XML element at path.
 *
 * path_name_array must be a C array of char*, with a NULL as its final entry.
 *
 * For example:
 * Given `xml_doc`: "<Error><Code>SlowDown</Code></Error>"
 * And `path_name_array`: {"Error", "Code", NULL}
 * `out_body` will get set to: "SlowDown"
 *
 * Returns AWS_OP_SUCCESS or AWS_OP_ERR.
 * Raises AWS_ERROR_STRING_MATCH_NOT_FOUND if path not found in XML,
 * or AWS_ERROR_INVALID_XML if the XML can't be parsed.
 *
 * DO NOT make this function public without a lot of thought.
 * The whole thing of passing a C-array of C-strings with a NULL sentinel
 * is unconventional for this codebase.
 */
AWS_S3_API
int aws_xml_get_body_at_path(
    struct aws_allocator *allocator,
    struct aws_byte_cursor xml_doc,
    const char *path_name_array[],
    struct aws_byte_cursor *out_body);

/* strip quotes if string is enclosed in quotes. does not remove quotes if they only appear on either side of the string
 */
AWS_S3_API
struct aws_string *aws_strip_quotes(struct aws_allocator *allocator, struct aws_byte_cursor in_cur);

/* TODO could be moved to aws-c-common. */
AWS_S3_API
int aws_last_error_or_unknown(void);

AWS_S3_API
void aws_s3_init_user_agent_header_cached(struct aws_s3_meta_request *meta_request);

AWS_S3_API
void aws_s3_apply_user_agent_header(struct aws_s3_meta_request *meta_request, struct aws_http_message *message);

/* Test-only: one-shot build-and-stamp without a meta_request. Exercises the same parsing logic as
 * aws_s3_init_user_agent_header_cached + aws_s3_apply_user_agent_header in a single call. */
AWS_S3_API
void aws_s3_add_user_agent_header(
    struct aws_allocator *allocator,
    struct aws_http_message *message,
    uint32_t feature_ids);

/**
 * Feature ID flags for the User-Agent `m/` section (UA 2.1 SEP).
 * Boolean flags tracked as a bitmask: client-level flags are derived from aws_s3_client_config in
 * aws_s3_client_new; each meta request copies them and ORs in per-request flags derived from
 * aws_s3_meta_request_options in aws_s3_meta_request_init_base. Feature IDs are allocated from the
 * shared AWS SDK feature-ID registry; do not invent new IDs here without registering them.
 */
enum aws_s3_feature_id {
    AWS_S3_FEATURE_ID_CUSTOM_PART_SIZE = (1 << 0),      /* AX - non-default part size configured */
    AWS_S3_FEATURE_ID_CUSTOM_THROUGHPUT = (1 << 1),     /* AY - non-default throughput target configured */
    AWS_S3_FEATURE_ID_CUSTOM_MEMORY_LIMIT = (1 << 2),   /* AZ - non-default memory pool size configured */
    AWS_S3_FEATURE_ID_ON_EC2 = (1 << 3),                /* Aa - running on EC2 instance */
    AWS_S3_FEATURE_ID_FILE_PATH = (1 << 4),             /* Ab - request used send_filepath or recv_filepath */
    AWS_S3_FEATURE_ID_CUSTOM_MEMORY_POOL = (1 << 5),    /* Aj - customer-provided memory pool */
    AWS_S3_FEATURE_ID_CLIENT_CREATED_FOR_OP = (1 << 6), /* Al - new S3 client created for this operation */
};

/* Given the response headers list, finds the Content-Range header and parses the range-start, range-end and
 * object-size. All output arguments are optional.*/
AWS_S3_API
int aws_s3_parse_content_range_response_header(
    struct aws_http_headers *response_headers,
    uint64_t *out_range_start,
    uint64_t *out_range_end,
    uint64_t *out_object_size);

/* Given a Content-Range header value as a byte cursor, parses the range-start, range-end and
 * object-size. All output arguments are optional. */
AWS_S3_API
int aws_s3_parse_content_range_cursor(
    struct aws_byte_cursor content_range_cursor,
    uint64_t *out_range_start,
    uint64_t *out_range_end,
    uint64_t *out_object_size);

/* Given response headers, parses the content-length from a content-length response header.*/
AWS_S3_API
int aws_s3_parse_content_length_response_header(
    struct aws_allocator *allocator,
    struct aws_http_headers *response_headers,
    uint64_t *out_content_length);

/*
 * Given the request headers list, finds the Range header and parses the range-start and range-end. All arguments are
 * required.
 * */
AWS_S3_API
int aws_s3_parse_request_range_header(
    struct aws_http_headers *request_headers,
    bool *out_has_start_range,
    bool *out_has_end_range,
    uint64_t *out_start_range,
    uint64_t *out_end_range);

/* Calculate the number of parts based on overall object-range and part_size. */
AWS_S3_API
uint32_t aws_s3_calculate_auto_ranged_get_num_parts(
    size_t part_size,
    uint64_t first_part_size,
    uint64_t object_range_start,
    uint64_t object_range_end);

/**
 * Calculates the optimal part size and num parts given the 'content_length' and 'client_part_size'.
 * This will increase the part size to stay within S3's number of parts.
 * If the required part size exceeds the 'client_max_part_size' or
 * if the system cannot support the required part size, it will raise an 'AWS_ERROR_INVALID_ARGUMENT' argument.
 */
AWS_S3_API
int aws_s3_calculate_optimal_mpu_part_size_and_num_parts(
    uint64_t content_length,
    size_t client_part_size,
    uint64_t client_max_part_size,
    size_t *out_part_size,
    uint32_t *out_num_parts);

/**
 * Whether a download may deliver bodies out of object order.
 *
 * Three inputs. The first preference expressed wins, and the destination's default applies when none is:
 *
 *  1. The request's override, then the client's setting. Either direction, either sink -- a preference
 *     passed through the API means the caller's own code is built around that answer.
 *  2. The environment's setting, asked only when neither of those said anything. Lets an operator change
 *     what an indifferent caller gets without overruling one who asked.
 *  3. What the destination defaults to. A file absorbs arrival order completely, since every part is
 *     written at its own absolute offset, so it defaults to out of order. A body callback surfaces the
 *     order to the caller through `range_start`, so it defaults to in order. Neither sink means there
 *     is nothing that could deliver out of order.
 *
 * A whole-object checksum that can only be built by hashing the body in object order is a correctness
 * constraint that outranks the answer here. It is applied by the caller rather than passed in, because
 * the constraint is not known at every call site -- see the auto-ranged GET's discovery finish, which
 * applies it there.
 *
 * Pure, so the policy can be exercised directly rather than inferred from a download's behaviour.
 */
AWS_S3_API
bool aws_s3_allow_out_of_order_delivery(
    bool file_sink,
    bool callback_sink,
    enum aws_tribool request_override,
    enum aws_tribool client_setting,
    enum aws_tribool env_setting);

/* Calculates the part range for a part given overall object range, size of each part, and the part's number. Note: part
 * numbers begin at one. Intended to be used in conjunction
 * with aws_s3_calculate_auto_ranged_get_num_parts. part_number should be less than or equal to the result of
 * aws_s3_calculate_auto_ranged_get_num_parts. */
AWS_S3_API
void aws_s3_calculate_auto_ranged_get_part_range(
    uint64_t object_range_start,
    uint64_t object_range_end,
    size_t part_size,
    uint64_t first_part_size,
    uint32_t part_number,
    uint64_t *out_part_range_start,
    uint64_t *out_part_range_end);

/* Match the retry-able S3 error code to CRT error code, return AWS_ERROR_UNKNOWN when not matched. */
AWS_S3_API
int aws_s3_crt_error_code_from_recoverable_server_error_code_string(struct aws_byte_cursor error_code_string);

AWS_S3_API
void aws_s3_request_finish_up_metrics_synced(struct aws_s3_request *request, struct aws_s3_meta_request *meta_request);

/* Check the response headers for checksum to verify, return a running checksum based on the algorithm found. If no
 * checksum found from header, return null. The caller is responsible for deciding whether the value describes the
 * bytes it intends to compare it against; this only reports what the headers carry. */
AWS_S3_API
int aws_s3_check_headers_for_checksum(
    struct aws_s3_meta_request *meta_request,
    const struct aws_http_headers *headers,
    struct aws_s3_checksum **out_checksum,
    struct aws_byte_buf *out_checksum_buffer);

/**
 * Calculate client-level optimal range size based on memory and connection constraints.
 * This function is called during client initialization to determine the base range size
 * using the formula: MemoryLimit / concurrency / divisor.
 * The result is rounded up to ensure proper alignment and applies minimum size constraints.
 *
 * @param memory_limit_in_bytes Total memory limit available for buffering
 * @param max_connections Maximum number of concurrent connections
 * @param out_client_optimal_range_size Output parameter for calculated client-level optimal range size
 * @return AWS_OP_SUCCESS on success, AWS_OP_ERR on failure (caller should fall back to default)
 */
AWS_S3_API
int aws_s3_calculate_client_optimal_range_size(
    uint64_t memory_limit_in_bytes,
    uint32_t max_connections,
    uint64_t *out_client_optimal_range_size);

/**
 * Calculate request-level optimal range size by considering object-specific information.
 * This function is called per request to adjust the client-level range size based on
 * estimated object stored part size using: min(client_optimal_range_size, estimated_object_stored_part_size).
 *
 * @param client_optimal_range_size The client-level optimal range size from initialization
 * @param estimated_object_stored_part_size Estimated size of object stored parts in S3
 * @param is_express If the request is a s3express request or not.
 * @param out_request_optimal_range_size Output parameter for calculated request-level optimal range size
 * @return AWS_OP_SUCCESS on success, AWS_OP_ERR on failure (caller should fall back to client size)
 */
AWS_S3_API
int aws_s3_calculate_request_optimal_range_size(
    uint64_t client_optimal_range_size,
    uint64_t estimated_object_stored_part_size,
    bool is_express,
    uint64_t *out_request_optimal_range_size);

/**
 * Extract the number of parts from an S3 ETag header value.
 * S3 multipart upload ETags have the format "<hash>-<number_of_parts>".
 * Single-part uploads have ETags without dashes.
 *
 * @param etag_header_value The ETag header value (may include quotes)
 * @param out_num_parts Output parameter for the number of parts (1 for single-part uploads)
 * @return AWS_OP_SUCCESS on success, AWS_OP_ERR on failure (invalid ETag format)
 */
AWS_S3_API
int aws_s3_extract_parts_from_etag(struct aws_byte_cursor etag_header_value, uint32_t *out_num_parts);

/**
 * Helper to figure out if given header name is one of the checksum value headers.
 * ex. returns true for x-amz-checksum-crc32 or x-amz-checksum-sha256, but false for x-amz-checksum-type.
 * Note: relies on hardcoded list of non-checksum headers, which needs to be updated if s3 expands list of those.
 */
AWS_S3_API
bool aws_s3_is_checksum_value_header_name(struct aws_byte_cursor header_name);

AWS_EXTERN_C_END

#endif /* AWS_S3_UTIL_H */
