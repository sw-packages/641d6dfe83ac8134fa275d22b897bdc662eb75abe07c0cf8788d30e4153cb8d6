#ifndef AWS_S3_REQUEST_H
#define AWS_S3_REQUEST_H

/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/common/byte_buf.h>
#include <aws/common/linked_list.h>
#include <aws/common/ref_count.h>
#include <aws/common/task_scheduler.h>
#include <aws/common/thread.h>
#include <aws/http/connection_manager.h>
#include <aws/s3/s3.h>

#include <aws/s3/private/s3_checksums.h>

struct aws_http_message;
struct aws_signable;
struct aws_s3_meta_request;

enum aws_s3_request_flags {
    AWS_S3_REQUEST_FLAG_RECORD_RESPONSE_HEADERS = 0x00000001,
    AWS_S3_REQUEST_FLAG_ALWAYS_SEND = 0x00000002,
    AWS_S3_REQUEST_FLAG_ALLOCATE_BUFFER_FROM_POOL = 0x00000004,
};

/**
 * Information sent in the telemetry_callback after each aws_s3_request finished/retried from meta request.
 */
struct aws_s3_request_metrics {
    struct aws_allocator *allocator;

    struct {
        /* The time stamp when the request was first initiated by the client, including the very first attempt.
         * This timestamp is set once at the beginning and never updated during retries. Timestamps are from
         * `aws_high_res_clock_get_ticks`. This will always be available. */
        int64_t s3_request_first_attempt_start_timestamp_ns;

        /* The time stamp when the request completely finished (success or final failure), including all retry
         * attempts. This is set when the request reaches its final state - either successful completion or
         * exhaustion of all retry attempts. Timestamps are from `aws_high_res_clock_get_ticks`. This will
         * be available with the last attempt. */
        int64_t s3_request_last_attempt_end_timestamp_ns;

        /* The total time duration for the complete request lifecycle from initial start to final completion,
         * including all retry attempts, backoff delays, and connection establishment time
         * (s3_request_last_attempt_end_timestamp_ns - s3_request_first_attempt_start_timestamp_ns). This represents the
         * end-to-end user experience time. This will be available with the last attempt. */
        int64_t s3_request_total_duration_ns;

        /* The time stamp when the request started by S3 client, which is prepared time by the client. Timestamps
         * are from `aws_high_res_clock_get_ticks`. This will always be available. */
        int64_t start_timestamp_ns;
        /* The time stamp when the request finished by S3 client succeed or failed or to be retried. Timestamps
         * are from `aws_high_res_clock_get_ticks`. This will always be available. */
        int64_t end_timestamp_ns;
        /* The time duration for the request from start to finish. end_timestamp_ns - start_timestamp_ns. This will
         * always be available. */
        int64_t total_duration_ns;

        /* The time stamp when the request started to be encoded. -1 means data not available. Timestamp
         * are from `aws_high_res_clock_get_ticks` */
        int64_t send_start_timestamp_ns;
        /* The time stamp when the request finished to be encoded. -1 means data not available.
         * Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t send_end_timestamp_ns;
        /* The time duration for the request from start encoding to finish encoding (send_end_timestamp_ns -
         * send_start_timestamp_ns). When send_end_timestamp_ns is -1, means data not available. */
        int64_t sending_duration_ns;

        /* The time stamp when the response started to be received from the network channel. -1 means data not
         * available. Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t receive_start_timestamp_ns;
        /* The time stamp when the response finished to be received from the network channel. -1 means data not
         * available. Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t receive_end_timestamp_ns;
        /* The time duration for the request from start receiving to finish receiving (receive_end_timestamp_ns -
         * receive_start_timestamp_ns). When receive_end_timestamp_ns is 0, means data not available. */
        int64_t receiving_duration_ns;

        /* The time stamp when the request started to be signed. -1 means data not
         * available. Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t sign_start_timestamp_ns;
        /* The time stamp when the response finished to be signed. -1 means data not
         * available. Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t sign_end_timestamp_ns;
        /* The time duration for the request from start signing to finish signing (sign_end_timestamp_ns -
         * sign_start_timestamp_ns). When sign_end_timestamp_ns is 0, means data not available. */
        int64_t signing_duration_ns;

        /* The time stamp when the request started to acquire memory. -1 means data not
         * available. Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t mem_acquire_start_timestamp_ns;
        /* The time stamp when the response to acquire memory. -1 means data not
         * available. Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t mem_acquire_end_timestamp_ns;
        /* The time duration for the request from start mem acquire to finish mem acquire (mem_acquire_end_timestamp_ns
         * - mem_acquire_start_timestamp_ns). When sign_end_timestamp_ns is 0, means data not available. */
        int64_t mem_acquire_duration_ns;

        /* The time stamp when the request started to be delivered (i.e. on body callback is invoked or write to file
         * initiated). -1 means data not available. Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t deliver_start_timestamp_ns;
        /* The time stamp when the response finished to be delivered. -1 means data not
         * available. Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t deliver_end_timestamp_ns;
        /* The time duration for the request from start of delivery to finish of delivery (deliver_end_timestamp_ns -
         * deliver_start_timestamp_ns). When deliver_duration_ns is 0, means data not available. */
        int64_t deliver_duration_ns;

        /* The time stamp when the request started to acquire connection. -1 means data not available. Timestamp
         * are from `aws_high_res_clock_get_ticks` */
        int64_t conn_acquire_start_timestamp_ns;
        /* The time stamp when the request finished to acquire connection. -1 means data not available.
         * Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t conn_acquire_end_timestamp_ns;
        /* The time duration for the request from start acquiring connection to finish acquiring connection
         * (conn_acquire_end_timestamp_ns - conn_acquire_start_timestamp_ns). When conn_acquire_end_timestamp_ns is -1,
         * means data not available. */
        int64_t conn_acquire_duration_ns;

        /* The time stamp when the request started to delay for retry. -1 means data not available. Timestamp
         * are from `aws_high_res_clock_get_ticks` */
        int64_t retry_delay_start_timestamp_ns;
        /* The time stamp when the request finished to delay for retry. -1 means data not available.
         * Timestamp are from `aws_high_res_clock_get_ticks` */
        int64_t retry_delay_end_timestamp_ns;
        /* The time duration for the request from start retry delay to finish retry delay (retry_delay_end_timestamp_ns
         * - retry_delay_start_timestamp_ns). When retry_delay_end_timestamp_ns is -1, means data not available. */
        int64_t retry_delay_duration_ns;

        /* The time duration for the service call from connection acquisition to first response byte. -1 means data not
         * available. */
        int64_t service_call_duration_ns;
    } time_metrics;

    struct {
        /* Response status code for the request */
        int response_status;
        /* HTTP Headers of the response received. */
        struct aws_http_headers *response_headers;
        /* Path and query of the request. */
        struct aws_string *request_path_query;
        /* The host address of the request. */
        struct aws_string *host_address;
        /* Whether the request was made over TLS (https) or plaintext (http). */
        bool is_https;
        /* The the request ID header value. */
        struct aws_string *request_id;
        /* The the extended request ID header value. */
        struct aws_string *extended_request_id;
        /* S3 operation name for the request */
        struct aws_string *operation_name;
        /* The type of request made */
        enum aws_s3_request_type request_type;
    } req_resp_info_metrics;

    /* Snapshot of the endpoint's HTTP connection manager metrics, taken right before this request asks
     * for a connection (i.e. right as the request goes to be sent). This reflects the manager's overall
     * state at that instant, not anything specific to this request alone. */
    struct aws_http_manager_metrics http_manager_metrics;

    struct {
        /* The IP address of the request connected to */
        struct aws_string *ip_address;
        /* The pointer to the connection that request was made from */
        void *connection_ptr;
        /* The pointer to the request that the request attempt was made from */
        void *request_ptr;
        /* The aws_thread_id_t to the thread that request ran on */
        aws_thread_id_t thread_id;
        /* The stream-id, which is the idex when the stream was activated. */
        uint32_t stream_id;
        /* CRT error code when the aws_s3_request finishes. */
        int error_code;
        /* Retry attempt. */
        uint32_t retry_attempt;
        /* Is the memory for the request allocated from the buffer pool or not. */
        bool memory_allocated_from_pool;
    } crt_info_metrics;

    /* TODO: align the part info metrics with the others, eg: `aws_s3_mpu_part_info`. */
    struct {
        /* Beginning range of this part. */
        uint64_t part_range_start;
        /* Last byte of this part. */
        uint64_t part_range_end;
        /* Part number that this request refers to. */
        uint32_t part_number;
    } part_info_metrics;

    struct aws_ref_count ref_count;
};

/* Represents a single request made to S3. */
struct aws_s3_request {

    /* Linked list node used for queuing. */
    struct aws_linked_list_node node;

    /* Timestamp when retry attempt started. Overwritten on each retry and copied to new attempt's setup data.
     * -1 means data not available. Timestamp from `aws_high_res_clock_get_ticks` */
    int64_t retry_start_timestamp_ns;
    /* Timestamp when retry attempt ended. Overwritten on each retry and copied to new attempt's setup data.
     * -1 means data not available. Timestamp from `aws_high_res_clock_get_ticks` */
    int64_t retry_end_timestamp_ns;

    /* Linked list node used for tracking the request is active from HTTP level. */
    struct aws_linked_list_node cancellable_http_streams_list_node;

    /* Linked list node used for tracking buffer acquire futures. */
    struct aws_linked_list_node pending_buffer_future_list_node;

    /* The meta request lock must be held to access the data */
    struct {
        /* The underlying http stream, only valid when the request is active from HTTP level */
        struct aws_http_stream *cancellable_http_stream;

        /* Buffer future. */
        struct aws_future_s3_buffer_ticket *buffer_future;
    } synced_data;

    /* TODO Ref count on the request is no longer needed--only one part of code should ever be holding onto a request,
     * and we can just transfer ownership.*/
    struct aws_ref_count ref_count;

    struct aws_allocator *allocator;

    /* Owning meta request. */
    struct aws_s3_meta_request *meta_request;

    /* The buffer size to be allocated for the request, defaults the part size. */
    size_t buffer_size;
    /* Request body to use when sending the request. The contents of this body will be re-used if a request is
     * retried.*/
    struct aws_byte_buf request_body;

    /* Set when the request will be streaming from file directly instead of the request_body. */
    bool fio_streaming;
    /* If file I/O options configure streaming. The request body will be streaming from this. If a request is retried,
     * this stream will be recreated. */
    struct aws_input_stream *request_body_stream;
    uint64_t content_length;

    /**
     * Ticket to acquire the buffer.
     */
    struct aws_s3_buffer_ticket *ticket;

    /* Beginning range of this part.  */
    uint64_t part_range_start;

    /* Last byte of this part.
     * Note: this is available on both put and get, but in put case it can be optimistic,
     * ex for unknown content length we dont know what the end will be until we finish reading data. */
    uint64_t part_range_end;

    /* Part number that this request refers to.  If this is not a part, this can be 0.  (S3 Part Numbers start at 1.)
     * However, must currently be a valid part number (ie: greater than 0) if the response body is to be streamed to the
     * caller.
     */
    uint32_t part_number;

    /* The upload_timeout used. Zero, if the request is not a upload part */
    size_t upload_timeout_ms;

    /* Number of times aws_s3_meta_request_prepare has been called for a request. During the first call to the virtual
     * prepare function, this will be 0.*/
    uint32_t num_times_prepared;

    /* checksum found in the header of an individual get part http request */
    struct aws_byte_buf request_level_response_header_checksum;

    /* Running checksum used to validate this part against its own checksum header, which
     * request_level_response_header_checksum holds the expected value for. NULL when the response carried no
     * checksum header of its own. Its algorithm is whichever one that header named. */
    struct aws_s3_checksum *request_level_running_response_sum;

    /* Running checksum used only to produce this part's digest for the meta request's whole-object combine.
     * NULL when this part does not contribute to a combine.
     *
     * Kept separate from request_level_running_response_sum because the two answer to different algorithms:
     * this one always uses the whole-object algorithm from the discovery response, while the validation sum
     * uses whatever algorithm this part's own checksum header named. Nothing requires those to agree — an
     * object can carry a whole-object CRC64NVME while its parts carry per-part CRC32 — and folding a digest
     * of the wrong algorithm would silently corrupt the whole-object sum. */
    struct aws_s3_checksum *request_level_combine_sum;
    /* The algorithm used to validate the checksum */
    enum aws_s3_checksum_algorithm validation_algorithm;

    /* Get request only, was there a checksum to validate */
    bool did_validate;

    /* Get request only, if there was an attached checksum to validate did it match the computed checksum */
    bool checksum_match;

    /* Tag that defines what the built request will actually consist of.  This is meant to be space for an enum defined
     * by the derived type.  Request tags do not necessarily map 1:1 with actual S3 API requests. (For example, they can
     * be more contextual, like "first part" instead of just "part".) */

    /* TODO: Eliminate the concept of "request tag" and just use request_type.
     * It's confusing having 2 concepts that are so similar.
     * There's only 1 case where 2 tags used the same type,
     * we can use some other bool/flag to differentiate this 1 case. */
    int request_tag;

    /* Actual S3 type for the single request (may be AWS_S3_REQUEST_TYPE_UNKNOWN) */
    enum aws_s3_request_type request_type;

    /* S3 operation name for the single request (e.g. "CompleteMultipartUpload") */
    struct aws_string *operation_name;

    /* Members of this structure will be repopulated each time the request is sent. If the request fails, and needs to
     * be retried, then the members of this structure will be cleaned up and re-populated on the next send.
     */
    /* TODO rename this anonymous structure to something more intuitive. (Maybe "attempt_data")*/
    struct {

        /* The HTTP message to send for this request. */
        struct aws_http_message *message;

        /* Signable created for the above message. */
        struct aws_signable *signable;

        /* Recorded response headers for the request. Set only when the request desc has record_response_headers set to
         * true or when this response indicates an error. */
        struct aws_http_headers *response_headers;

        /* Recorded response body of the request. */
        struct aws_byte_buf response_body;

        /* Returned response status of this request. */
        int response_status;

        /* Returned request ID of this request. */
        struct aws_string *request_id;
        /* Returned extended request id of this request. */
        struct aws_string *amz_id_2;

        /* The metrics for the request telemetry */
        struct aws_s3_request_metrics *metrics;

        /* The request is required to have the unsigned payload */
        uint32_t require_streaming_unsigned_payload_header : 1;
    } send_data;

    /* When true, response headers from the request will be stored in the request's response_headers variable. */
    uint32_t record_response_headers : 1;

    /* Indicates whether buffer should be allocated for the request from the pool. */
    uint32_t should_allocate_buffer_from_pool : 1;

    /* When true, this request is being tracked by the client for limiting the amount of in-flight-requests/stats. */
    uint32_t tracked_by_client : 1;

    /* When true, even when the meta request has a finish result set, this request will be sent. */
    uint32_t always_send : 1;

    /* When true, this request is intended to find out the object size. This is currently only used by auto_range_get.
     */
    uint32_t discovers_object_size : 1;

    /* When true, this request does not represent a useful http request and
     * must not be sent, however client must still call corresponding finished
     * callback for the request. Those requests can occur when request is
     * optimistically created during update, but cannot be prepared. ex. when
     * put has no content length, requests will be scheduled as regular to
     * ensure fair distribution against other requests, but can also result in
     * requests for uploading data after the end of the stream (those requests
     * will use below flag to indicate that they should not be sent). */
    uint32_t is_noop : 1;

    /* When true, this request has already been uploaded. we still prepare the request to check the durability. */
    uint32_t was_previously_uploaded : 1;
};

AWS_EXTERN_C_BEGIN

/* Create a new s3 request structure with the given options. */
AWS_S3_API
struct aws_s3_request *aws_s3_request_new(
    struct aws_s3_meta_request *meta_request,
    int request_tag,
    enum aws_s3_request_type request_type,
    uint32_t part_number,
    uint32_t flags);

/* Gets the size of the part payload.
 * Range is inclusive (i.e. 0-0 range has 1 byte size). In case of misconfigured range returns 0. */
AWS_S3_API
uint64_t aws_s3_request_get_payload_size(struct aws_s3_request *request);

/* Set up the request to be sent. Called each time before the request is sent. Will initially call
 * aws_s3_request_clean_up_send_data to clear out anything previously existing in send_data. */
AWS_S3_API
void aws_s3_request_setup_send_data(struct aws_s3_request *request, struct aws_http_message *message);

/* Clear out send_data members so that they can be repopulated before the next send. */
AWS_S3_API
void aws_s3_request_clean_up_send_data(struct aws_s3_request *request);

AWS_S3_API
struct aws_s3_request *aws_s3_request_acquire(struct aws_s3_request *request);

AWS_S3_API
struct aws_s3_request *aws_s3_request_release(struct aws_s3_request *request);

AWS_S3_API
struct aws_s3_request_metrics *aws_s3_request_metrics_new(struct aws_allocator *allocator);

AWS_EXTERN_C_END

#endif
